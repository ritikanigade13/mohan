const fileInput = document.getElementById('fileInput');
const rootFolder = document.getElementById('rootFolder');

fileInput.addEventListener('change', handleFileUpload);

function handleFileUpload(event) {
    rootFolder.innerHTML = '';

    const files = event.target.files;

    for (const file of files) {
        if (file.type === 'application/x-directory') {
            displayFolder(file, rootFolder);
        } else {
            displayFile(file, rootFolder);
        }
    }
}

function displayFile(file, parentNode) {
    const fileNode = document.createElement('li');
    const icon = document.createElement('i');
    icon.className = 'fas fa-file';
    fileNode.appendChild(icon);
    fileNode.innerHTML += ' ' + file.name;
    fileNode.addEventListener('click', () => displayFileData(file));
    parentNode.appendChild(fileNode);
}

function displayFolder(folder, parentNode) {
    const folderNode = document.createElement('li');
    const icon = document.createElement('i');
    icon.className = 'fas fa-folder';
    folderNode.appendChild(icon);

    const folderTitle = document.createElement('span');
    folderTitle.innerText = ' ' + folder.name;
    folderTitle.addEventListener('click', toggleFolder);
    folderNode.appendChild(folderTitle);

    const folderList = document.createElement('ul');
    folderList.style.display = 'none'; // Start with subfolders collapsed
    folderNode.appendChild(folderList);
    parentNode.appendChild(folderNode);

    const reader = folder.createReader();
    reader.readEntries(entries => {
        entries.forEach(entry => {
            if (entry.isDirectory) {
                displayFolder(entry, folderList);
            } else {
                displayFile(entry, folderList);
            }
        });
    });
}

function toggleFolder(event) {
    const folderNode = event.target.parentNode;
    const folderList = folderNode.querySelector('ul');
    if (folderList.style.display === 'none') {
        folderList.style.display = 'block';
    } else {
        folderList.style.display = 'none';
    }
}

function displayFileData(file) {
    const reader = new FileReader();
    reader.onload = function (event) {
        console.log(`Content of ${file.name}:`);
        console.log(event.target.result);
    };
    reader.readAsText(file);
}
