import { Component, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
  @ViewChild('folderUploader') folderUploaderRef!: ElementRef<HTMLInputElement>;
  rootDir: string = '';
  fileTree: any = null;
  fileTreeHtml: any = null;

  constructor(private sanitizer: DomSanitizer) {}

  ngAfterViewInit(): void {
    this.setupJQueryEventListeners();
  }

  onFolderUploaderChange(event: Event): void {
    const target = event.target as HTMLInputElement;
    this.rootDir = target.files![0].webkitRelativePath.split('/')[0];
    const fileList = Array.from(target.files!);

    this.fileTree = this.buildFileTree(this.rootDir, fileList);
    this.fileTreeHtml = this.buildTreeHtml(this.fileTree);
  }

  buildFileTree(rootDir: string, fileList: File[]): any {
    const fileTree = {};

    fileList.forEach(file => {
      const pathParts = file.webkitRelativePath.split('/');
      let currentNode = fileTree;

      pathParts.forEach(part => {
        if (!currentNode[part]) {
          currentNode[part] = {};
        }
        currentNode = currentNode[part];
      });
    });

    return fileTree;
  }

  buildTreeHtml(node: any): any[] {
    const treeHtml: any[] = [];

    for (const key in node) {
      if (node.hasOwnProperty(key)) {
        const subTree = {
          name: key,
          isFolder: Object.keys(node[key]).length > 0,
          expanded: false,
          children: this.buildTreeHtml(node[key])
        };
        treeHtml.push(subTree);
      }
    }

    return treeHtml;
  }

  toggleFolder(node: any): void {
    node.expanded = !node.expanded;
  }

  onTreeNodeClick(node: any): void {
    if (!node.isFolder) {
      const filePath = this.getPath(this.fileTree, node.name);
      this.displayFileData(filePath);
    }
  }

  getPath(node: any, targetFileName: string): string | null {
    for (const key in node) {
      if (node.hasOwnProperty(key)) {
        if (key === targetFileName) {
          return key;
        }
        const path = this.getPath(node[key], targetFileName);
        if (path !== null) {
          return key + '/' + path;
        }
      }
    }
    return null;
  }

  displayFileData(filePath: string): void {
    const fileList = Array.from(this.folderUploaderRef.nativeElement.files as FileList);
    const selectedFile = fileList.find(file => file.webkitRelativePath === filePath);
    if (selectedFile) {
      const reader = new FileReader();

      reader.onload = (event: ProgressEvent<FileReader>) => {
        console.log('File:', selectedFile.name);
        console.log('Data:', event.target!.result);
      };

      reader.readAsText(selectedFile);
    }
  }

  private setupJQueryEventListeners(): void {
    this.folderUploaderRef.nativeElement.addEventListener('change', (e: Event) => {
      const rootDir = (e.target as HTMLInputElement).files![0].webkitRelativePath.split('/')[0];
      const fileList = Array.from((e.target as HTMLInputElement).files!);
  
      this.fileTree = this.buildFileTree(rootDir, fileList);
      this.fileTreeHtml = this.buildTreeHtml(this.fileTree);
    });
  }
  
}
