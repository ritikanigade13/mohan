import { Component , OnInit } from '@angular/core';


@Component({
  selector: 'app-folder-upload',
  templateUrl: './folder-upload.component.html',
  styleUrls: ['./folder-upload.component.css']
})
export class FolderUploadComponent implements OnInit  {
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  
  
}
