const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const app = express();
const port = 3000;

app.use(express.static(__dirname));

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/')
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.post('/upload', upload.any(), (req, res) => {
    const uploadedFiles = req.files;
    processUploadedFiles(uploadedFiles);
    res.send('Files uploaded successfully.');
});

function processUploadedFiles(files, currentPath = '') {
    files.forEach(file => {
        const filePath = path.join(currentPath, file.originalname);

        if (file.mimetype === 'application/x-directory') {
            const subFiles = fs.readdirSync(file.path);
            const subFolderPath = path.join(currentPath, file.originalname);

            if (!fs.existsSync(subFolderPath)) {
                fs.mkdirSync(subFolderPath);
            }

            processUploadedFiles(subFiles.map(subFile => ({
                originalname: subFile,
                path: path.join(file.path, subFile),
                mimetype: fs.statSync(path.join(file.path, subFile)).isDirectory() ? 'application/x-directory' : 'application/octet-stream'
            })), subFolderPath);
        } else {
            fs.renameSync(file.path, filePath);
        }
    });
}

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
